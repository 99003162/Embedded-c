/*
 * funct.c
 *
 *  Created on: Jan 2, 2021
 *      Author: 99003162
 */

#include <funct.h>
#include "main.h"

void systembegin(uint8_t f) {
	HAL_GPIO_WritePin(GreenLed_GPIO_Port, GreenLed_Pin, f);
}

uint16_t AnalogRead(ADC_HandleTypeDef analog)
{
	HAL_ADC_Start(&analog);
	uint16_t digital;
    if(HAL_ADC_PollForConversion(&analog, 5)== HAL_OK) {
		digital = HAL_ADC_GetValue(&analog);
    }
    return digital;
}
